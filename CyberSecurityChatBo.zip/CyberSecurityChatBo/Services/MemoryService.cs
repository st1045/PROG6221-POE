﻿namespace CyberSecurityChatBot.Services
{
    public class MemoryService
    {
        public string UserName { get; set; }

        public string FavouriteTopic { get; set; }
    }
}