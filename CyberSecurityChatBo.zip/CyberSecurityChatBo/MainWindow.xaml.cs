﻿using System;
using System.Windows;
using CyberSecurityChatBot.Services;


namespace CyberSecurityChatBo
{
    // If chatbot not found, display minmal value
    public class ChatbotService
    {
        // Add methods 
    }

    public partial class MainWindow : Window
    {
        private ChatbotService chatbot;

        public MainWindow()
        {
            InitializeComponent();

            chatbot = new ChatbotService();
            AudioService.PlayGreeting();

            LoadAsciiArt();
            PlayGreeting();

            AppendMessage("Bot", "Hello! Welcome to the Cybersecurity Awareness Bot.");
            AppendMessage("Bot", "What is your name?");
        }

        private void LoadAsciiArt()
        {
            AsciiArtBlock.Text = @"
      _____       _               
  / ____|     | |              
 | |    _   _ | |__    ___ _ __
 | |   | | | || '_ \  / _ \ '__|
 | |___| |_| || |_) ||  __/ |   
  \_____\__, ||_.__/  \___|_|   
         __/ |                  
        |___/              




";
        }

        private void AppendMessage(string sender, string message)
        {
            ChatHistoryBlock.Text += $"{sender}: {message}{Environment.NewLine}";
        }

        private void PlayGreeting()
        {
            //  Greeting Logic
        }
    }
}