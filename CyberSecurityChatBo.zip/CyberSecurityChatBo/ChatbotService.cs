using System;
using System.Collections.Generic;

namespace CyberSecurityChatBot.Services
{
    public class ChatbotService
    {
        private Dictionary<string, List<string>> keywordResponses;
        private Random random;
        private string lastTopic = "";

        public ChatbotService()
        {
            random = new Random();

            keywordResponses = new Dictionary<string, List<string>>();

            keywordResponses.Add("password", new List<string>
            {
                "Use strong passwords with symbols and numbers.",
                "Avoid using personal information in passwords.",
                "Use a different password for each account."
            });

            keywordResponses.Add("phishing", new List<string>
            {
                "Never click suspicious email links.",
                "Verify the sender before opening attachments.",
                "Phishing emails often create urgency to trick users."
            });

            keywordResponses.Add("privacy", new List<string>
            {
                "Review your privacy settings regularly.",
                "Avoid sharing sensitive information online.",
                "Enable two-factor authentication for better privacy."
            });
        }

        public string GetResponse(string input)
        {
            input = input.ToLower();

            foreach (var keyword in keywordResponses.Keys)
            {
                if (input.Contains(keyword))
                {
                    lastTopic = keyword;
                    return GetRandomResponse(keyword);
                }
            }

            if (input.Contains("tell me more") || input.Contains("another tip"))
            {
                if (!string.IsNullOrEmpty(lastTopic))
                {
                    return GetRandomResponse(lastTopic);
                }
            }

            if (input.Contains("worried"))
            {
                return "It is understandable to feel worried. Stay alert online and avoid suspicious links.";
            }

            return "I’m not sure I understand. Can you try rephrasing?";
        }

        private string GetRandomResponse(string keyword)
        {
            List<string> responses = keywordResponses[keyword];
            int index = random.Next(responses.Count);
            return responses[index];
        }
    }
}
